package com.troll.lock

import android.content.pm.ApplicationInfo
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AppAdapter(
    private val selected: MutableSet<String>,
    private val cb: (String, Boolean) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    private var apps: List<ApplicationInfo> = emptyList()

    fun submit(list: List<ApplicationInfo>) { apps = list; notifyDataSetChanged() }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val name: TextView = v.findViewById(R.id.name)
        val pkg: TextView = v.findViewById(R.id.pkg)
        val check: CheckBox = v.findViewById(R.id.check)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false))

    override fun onBindViewHolder(h: VH, pos: Int) {
        val a = apps[pos]
        h.icon.setImageDrawable(h.itemView.context.packageManager.getApplicationIcon(a))
        h.name.text = a.loadLabel(h.itemView.context.packageManager)
        h.pkg.text = a.packageName
        h.check.setOnCheckedChangeListener(null)
        h.check.isChecked = selected.contains(a.packageName)
        h.check.setOnCheckedChangeListener { _, c ->
            if (c) selected.add(a.packageName) else selected.remove(a.packageName)
            cb(a.packageName, c)
        }
    }

    override fun getItemCount() = apps.size
}